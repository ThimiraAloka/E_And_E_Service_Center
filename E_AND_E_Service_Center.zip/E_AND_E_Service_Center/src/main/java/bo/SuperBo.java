package bo;

public interface SuperBo {
}
