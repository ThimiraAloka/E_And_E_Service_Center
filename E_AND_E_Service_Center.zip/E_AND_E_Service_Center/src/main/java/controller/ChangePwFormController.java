package controller;

import com.jfoenix.controls.JFXTextField;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;

public class ChangePwFormController {


    public JFXTextField txtNewPassword;
    public JFXTextField txtNewPasswordConfirm;

    @FXML
    void backLogInButtonOnAction(ActionEvent event) {

    }

    @FXML
    void passworRestButtonOnAction(ActionEvent event) {

    }

}
