public class Main {
    public static void main(String[] args) {

        AppInitializer.main(args);
    }
}