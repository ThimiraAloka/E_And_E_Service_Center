package dao;

public interface SuperDao {
}
