package dao.util;

public enum DaoType {
    USER,ITEM,CUSTOMER;
}
