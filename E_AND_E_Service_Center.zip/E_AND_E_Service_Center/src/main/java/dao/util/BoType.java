package dao.util;

public enum BoType {
    USER,ITEM,CUSTOMER
}
